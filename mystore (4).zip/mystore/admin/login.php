<?php
// Redirect admin login page to unified login page
header('Location: ../pages/login.php');
exit();
