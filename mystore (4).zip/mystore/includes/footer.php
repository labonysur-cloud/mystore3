</main>
<footer>
    <p>&copy; <?= date('Y') ?> My Store. All rights reserved.</p>
</footer>
<script src="../assets/js/main.js"></script>
</body>
</html>
