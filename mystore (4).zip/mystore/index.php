<?php
header('Location: pages/products.php');
exit;
